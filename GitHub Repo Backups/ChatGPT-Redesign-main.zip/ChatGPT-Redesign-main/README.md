### ChatGPT Redesign
Please note that this is just an interface redesign, there's no included functionality! It's just a fun little project I'm working on in My free time.

<br>  

> [!NOTE]
> It's far from being finished so it will look very bad (for now).
