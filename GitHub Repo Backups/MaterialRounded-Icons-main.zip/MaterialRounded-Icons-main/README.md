### Welcome, Hope You Enjoy!
I use a lot of the icons Myself when making websites or web based applications. Mostly the Material Rounded icons as they look clean and modern!

<br>  

### What Icons Are There?
- Social Media
- Interface
- Wildlife  
  And more!

<br>  

### Credit
All icons were downloaded from [Icons8](https://icons8.com).

<br>  

### Upcoming
In the future, this repo will contain all kinds of icons. Sharp, Rounded, Filled, Outlined, etc. Multiple sources will also be used (Icons8, Figma, etc).
