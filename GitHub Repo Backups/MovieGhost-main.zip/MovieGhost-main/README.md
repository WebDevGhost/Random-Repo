### Sources
Where do the movies come from? Here's the sources used (please note that all movies have been purchased directly or via subscriptions):
- YouTube
- Netflix
- Prime Video

### To-Do List
- Redesign the whole site (movie bodies as rounded tablets instead of bars)
- Make the site more responsive (mobile and tablet devices)
- Add search filters
- Add more info to movie bodies (banner, language, movie length, etc)
