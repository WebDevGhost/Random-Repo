# MultiOS-VM-Concept
A concept based multi OS virtual machine that launches all types and versions of operating systems.  
Please note that this is just a concept design and doesn't actually do anything! Just got bored and wanted to do some designing.
